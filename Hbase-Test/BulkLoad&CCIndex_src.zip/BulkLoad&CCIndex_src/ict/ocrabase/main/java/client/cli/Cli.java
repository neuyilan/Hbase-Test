/**
 * 
 */
package ict.ocrabase.main.java.client.cli;

/**
 * @author Mid Liu
 * 
 */
public abstract class Cli {
	protected abstract void setFormat();

	protected abstract void checkArgs();
}
