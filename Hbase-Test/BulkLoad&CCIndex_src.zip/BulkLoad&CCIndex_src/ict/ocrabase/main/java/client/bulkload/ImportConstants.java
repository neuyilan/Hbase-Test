package ict.ocrabase.main.java.client.bulkload;


/**
 * Define some constants for importing
 * @author gu
 *
 */
public class ImportConstants {

	/* Describe the index type, include ccindex, secondaryindex, etc.*/
//	public static final String INDEX_TYPE_CCINDEX = IndexType.CCINDEX.toString();
//	public static final String INDEX_TYPE_SECONDARYINDEX = IndexType.SECONDARYINDEX.toString();
//	public static final String INDEX_TYPE_IMPSECONDARYINDEX = IndexType.IMPSECONDARYINDEX.toString();
	
	public static final String DATA_FORMAT = "DATA_FORMAT";
	public static final String BULKLOAD_DATA_FORMAT = "bulkload.dataFormat";
	public static final String BULKLOAD_DATA_FORMAT_WITH_KEY = "bulkload.dataFormat.withkey";
	public static final String CACHED_ROWS = "1000";
	
	public static final String KEY="KEY";
	public static final String TIMESTAMP="TIMESTAMP";
}
