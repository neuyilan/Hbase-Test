package ict.ocrabase.main.java.regionserver;

/**
 * DataType
 */
/* Describe the column data type , include String, Integer, Long, Double, etc.*/
public enum DataType {
  TINYINT, SHORT, MEDIUMINT, INT, LONG, DOUBLE, STRING, BOOLEAN,BYTES;
  
//  public String toString(){
//		return super.toString().toLowerCase();
//	}
}